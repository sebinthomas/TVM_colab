Optimize Tensor Operators
-------------------------
