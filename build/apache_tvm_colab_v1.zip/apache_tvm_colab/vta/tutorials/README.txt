.. _vta-tutorials:

VTA Tutorials
=============
This page contains tutorials about VTA and how to use TVM/Relay to target VTA.
